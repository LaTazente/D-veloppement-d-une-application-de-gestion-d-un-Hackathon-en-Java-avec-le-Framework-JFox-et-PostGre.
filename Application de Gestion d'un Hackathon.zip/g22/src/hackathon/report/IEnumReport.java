package hackathon.report;


public interface IEnumReport {

	String getPath();

}